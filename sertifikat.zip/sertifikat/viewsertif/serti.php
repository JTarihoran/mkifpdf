<?php
require('../fpdf/fpdf.php');

function AddText($pdf, $text, $x, $y, $a, $f, $t, $s, $r, $g, $b, $underline = false) {
    $pdf->SetFont($f, $t, $s);
    $pdf->SetXY($x, $y);
    $pdf->SetTextColor($r, $g, $b);

        if ($underline) {
            $lineHeight = 0.15;
            $textWidth = $pdf->GetStringWidth($text);
            $pdf->Cell($textWidth, $lineHeight, '', 'B', 10, 'R', true);
        }

    $pdf->Cell(0, 10, $text, 0, 0, $a);
}

// Create A4 Landscape page
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetCreator('JT');
// Add background image for PDF
$pdf->Image('../template2.jpg', 0, 0, 0);

// Add a Name to the certificate
AddText($pdf, ucwords('Parameter Nama '), 0, 100, 'C', 'times', 'B', 30, 3, 84, 156);
AddText($pdf, ucwords('Parameter Course '), 25, 120, 'C', 'times', 'B', 20, 3, 84, 156);

AddText($pdf, ucwords('_________________'), 25, 121, 'C', 'times', 'B', 20, 3, 84, 156);
AddText($pdf, ucwords('100'), 0, 140, 'C', 'times', 'B', 40, 3, 84, 156);
AddText($pdf, ucwords('Memuaskan'), 0, 148, 'C', 'times', 'B', 10, 3, 84, 156);


$pdf->Output();
?>
