<?php
require('../fpdf/fpdf.php');

//$name = text to be added, $x= x cordinate, $y = y coordinate, $a = alignment , $f= Font Name, $t = Bold / Italic, $s = Font Size, $r = Red, $g = Green Font color, $b = Blue Font Color
function AddText($pdf, $text, $x, $y, $a, $f, $t, $s, $r, $g, $b) {
$pdf->SetFont($f,$t,$s);	
$pdf->SetXY($x,$y);
$pdf->SetTextColor($r,$g,$b);
$pdf->Cell(0,10,$text,0,0,$a);	
}

//Create A 4 Landscape page
$pdf = new FPDF('L','mm','A4');
function CreatePage($pdf,$name)
    {
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->SetCreator('JT');
    // Add background image for PDF
    $pdf->Image('../template2.jpg',0,0,0);	

    //Add a Name to the certificate

    // AddText($pdf,ucwords($name), 0,80, 'C', 'Helvetica','B',30,3,84,156);
    // Add a Name to the certificate
    AddText($pdf, ucwords($name), 0, 100, 'C', 'times', 'B', 30, 3, 84, 156);
    AddText($pdf, ucwords('Parameter Course '), 25, 120, 'C', 'times', 'B', 20, 3, 84, 156);

    AddText($pdf, ucwords('_________________'), 25, 121, 'C', 'times', 'B', 20, 3, 84, 156);
    AddText($pdf, ucwords('100'), 0, 140, 'C', 'times', 'B', 40, 3, 84, 156);
    AddText($pdf, ucwords('Memuaskan'), 0, 148, 'C', 'times', 'B', 10, 3, 84, 156);
    }
CreatePage($pdf,'Sungkono');

CreatePage($pdf,'Prayoga');

CreatePage($pdf,'Jamaluddin');

$pdf->Output();
?>